## Commands:
  - `npm install`: to install dependencies
  - `npm start`: to start demo

## Known bugs:
  - line width & height can be negetive

## Others
  increase limit file watcher command on linux:
  ```
    sudo sysctl -w fs.inotify.max_user_watches=100000
  ```